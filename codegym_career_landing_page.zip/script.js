$(document).ready(function () {
    $(window).on("scroll", function () {
        if ($(this).scrollTop() > 50) {
            $(".navbar").addClass("scrolled");
            $("#backTop").fadeIn(200);
        } else {
            $(".navbar").removeClass("scrolled");
            $("#backTop").fadeOut(200);
        }
    });

    $("#backTop").on("click", function () {
        $("html, body").animate({ scrollTop: 0 }, 500);
    });

    $("#careerForm").on("submit", function (event) {
        event.preventDefault();
        $("#formMessage")
            .removeClass("text-danger")
            .addClass("text-success")
            .text("Đăng ký thành công! Đây là bản demo giao diện, chưa kết nối máy chủ.");
        this.reset();
    });

    $(".navbar-nav .nav-link, .navbar-nav .btn").on("click", function () {
        $(".navbar-collapse").collapse("hide");
    });
});
