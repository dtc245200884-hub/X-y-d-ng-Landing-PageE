# CodeGym Career - Landing Page

## Mục tiêu
Landing Page được xây dựng lại từ nội dung của trang CodeGym Career theo phong cách Material Design, sử dụng Bootstrap + MDBootstrap.

## Thành phần
- `index.html`: cấu trúc Landing Page.
- `style.css`: CSS tùy chỉnh, Material card, responsive và bố cục.
- `script.js`: navbar khi cuộn, nút lên đầu trang, đóng menu mobile và xử lý form demo.

## Các phần chính
1. Navbar
2. Hero / CTA
3. Tổng quan chương trình
4. Lợi ích và trải nghiệm học tập
5. Lộ trình Coding Bootcamp
6. Khóa học CGC JAVA / CGC PHP
7. Dịch vụ việc làm
8. Thống kê
9. Form đăng ký tư vấn
10. Footer

## Chạy bài
Mở `index.html` bằng trình duyệt. Các thư viện Bootstrap Material Design được tải từ CDN nên cần Internet để hiển thị đầy đủ.

## Nộp bài
Đưa 3 file `index.html`, `style.css`, `script.js` lên GitHub hoặc CodePen rồi nộp link repository/CodePen.
